import { createContext } from "react";
const otpContext = createContext();

export default otpContext;